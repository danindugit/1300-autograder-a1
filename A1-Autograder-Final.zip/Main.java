public class Main {
    public static void main(String[] args) {
        A1Autograder a1 = new A1Autograder();
        a1.runGrader();
    }
}
