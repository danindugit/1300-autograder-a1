# 1300-autograder-a1

### Welcome to the autograder for assignment 1 of CIS 1300

## Running the autograder
1. Log into the school server and make sure you have all the contents of this folder in a designated directory.

2. In the socs linux terminal, run the command `javac A1Autograder.java Check.java Main.java`. This will create the .class files.

3. In the socs linux terminal, run the command `java Main`. This will run the autograder.

## Associated links:
**Grading Scheme:**
https://docs.google.com/document/d/1YXR_r4MlrMBWXazCkk2b6OZmb78HpGQYwGhBaYP6y5E/edit?usp=sharing

**Test Cases:**
https://docs.google.com/document/d/1QGLb7M4Q0LymSq7wl8MWwE2Xn6oBC2yh9gfsNxoSw50/edit?usp=sharing
